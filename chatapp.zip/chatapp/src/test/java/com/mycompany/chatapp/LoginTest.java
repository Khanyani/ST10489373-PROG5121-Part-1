/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.chatapp; 

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class LoginTest {

    private Login login;

    @BeforeEach
    public void setUp() {
        login = new Login();
    }

    // checkUserName Tests

    @Test
    public void testCheckUserName_Valid() {
        assertTrue(login.checkUserName("kha_1"),
                "Username with underscore and <= 5 chars should be valid.");
    }

    @Test
    public void testCheckUserName_TooLong() {
        assertFalse(login.checkUserName("khan_1"),
                "Username longer than 5 characters should be invalid.");
    }

    @Test
    public void testCheckUserName_NoUnderscore() {
        assertFalse(login.checkUserName("khan1"),
                "Username without underscore should be invalid.");
    }

    @Test
    public void testCheckUserName_TooLongAndNoUnderscore() {
        assertFalse(login.checkUserName("khan123"),
                "Username that is too long and has no underscore should be invalid.");
    }

    // checkPasswordComplexity Tests
    @Test
    public void testCheckPasswordComplexity_Valid() {
        assertTrue(login.checkPasswordComplexity("Pass@123"),
                "Password with capital, number, special char, and >= 8 chars should be valid.");
    }

    @Test
    public void testCheckPasswordComplexity_TooShort() {
        assertFalse(login.checkPasswordComplexity("Pa@1"),
                "Password shorter than 8 characters should be invalid.");
    }

    @Test
    public void testCheckPasswordComplexity_NoCapital() {
        assertFalse(login.checkPasswordComplexity("pass@123"),
                "Password without a capital letter should be invalid.");
    }

    @Test
    public void testCheckPasswordComplexity_NoNumber() {
        assertFalse(login.checkPasswordComplexity("Password@"),
                "Password without a number should be invalid.");
    }

    @Test
    public void testCheckPasswordComplexity_NoSpecialCharacter() {
        assertFalse(login.checkPasswordComplexity("Password1"),
                "Password without a special character should be invalid.");
    }

    // checkCellPhoneNumber Tests

    @Test
    public void testCheckCellPhoneNumber_Valid() {
        assertTrue(login.checkCellPhoneNumber("+27831234567"),
                "Phone number starting with +27 and exactly 12 characters should be valid.");
    }

    @Test
    public void testCheckCellPhoneNumber_TooShort() {
        assertFalse(login.checkCellPhoneNumber("+2783123"),
                "Phone number shorter than 12 characters should be invalid.");
    }

    @Test
    public void testCheckCellPhoneNumber_TooLong() {
        assertFalse(login.checkCellPhoneNumber("+278312345678"),
                "Phone number longer than 12 characters should be invalid.");
    }

    @Test
    public void testCheckCellPhoneNumber_NoInternationalCode() {
        assertFalse(login.checkCellPhoneNumber("0831234567"),
                "Phone number without +27 international code should be invalid.");
    }

    // registerUser Tests

    @Test
    public void testRegisterUser_Success() {
        String result = login.registerUser("kha_1", "Pass@123", "+27831234567");
        assertEquals("User registered successfully.", result,
                "Valid details should register the user successfully.");
    }

    @Test
    public void testRegisterUser_InvalidUsername() {
        String result = login.registerUser("khan_1", "Pass@123", "+27831234567");
        assertEquals(
                "Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.",
                result,
                "Invalid username should return the correct error message.");
    }

    @Test
    public void testRegisterUser_InvalidPassword() {
        String result = login.registerUser("kha_1", "weakpass", "+27831234567");
        assertEquals(
                "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.",
                result,
                "Invalid password should return the correct error message.");
    }

    @Test
    public void testRegisterUser_InvalidPhoneNumber() {
        String result = login.registerUser("kha_1", "Pass@123", "0831234567");
        assertEquals("Cell phone number incorrectly formatted or does not contain international code.",
                result,
                "Invalid phone number should return the correct error message.");
    }

    // loginUser Tests

    @Test
    public void testLoginUser_Success() {
        login.registerUser("kha_1", "Pass@123", "+27831234567");
        assertTrue(login.loginUser("kha_1", "Pass@123"),
                "Correct credentials should return true.");
    }

    @Test
    public void testLoginUser_WrongPassword() {
        login.registerUser("kha_1", "Pass@123", "+27831234567");
        assertFalse(login.loginUser("kha_1", "wrongPass@1"),
                "Wrong password should return false.");
    }

    @Test
    public void testLoginUser_WrongUsername() {
        login.registerUser("kha_1", "Pass@123", "+27831234567");
        assertFalse(login.loginUser("abc_1", "Pass@123"),
                "Wrong username should return false.");
    }

    // returnLoginStatus Tests

    @Test
    public void testReturnLoginStatus_Success() {
        login.registerUser("kha_1", "Pass@123", "+27831234567");
        boolean result = login.loginUser("kha_1", "Pass@123");
        assertEquals("Welcome kha_1, it is great to see you again.",
                login.returnLoginStatus(result),
                "Successful login should return the welcome message with the username.");
    }

    @Test
    public void testReturnLoginStatus_Failure() {
        login.registerUser("kha_1", "Pass@123", "+27831234567");
        boolean result = login.loginUser("kha_1", "wrongPass@1");
        assertEquals("Username or password incorrect, please try again.",
                login.returnLoginStatus(result),
                "Failed login should return the error message.");
    }
}
