/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatapp;

/**
 *
 * @author Student
 */
import java.util.Scanner;
public class MainApp {
    public static void main(String[]args){
        
        // A scanner will allow the user to enter information
        Scanner input = new Scanner(System.in);
        
        // A method that will create an object of the login class
        Login login = new Login();
        
        // ---REGISTRATION SECTION ---
        System.out.println("=== USER REGISTRATION ===");

        boolean isRegistered = false;

        while (!isRegistered) {
        
            System.out.print("Enter a username:");
            String username = input.nextLine();
            
            System.out.print("Enter a password:");
            String password = input.nextLine();
            
            System.out.print("Enter your South African phone number (+27...):");
            String phone = input.nextLine();
            
            //call the resgiterUser
            //Store the message it returns
            String response = login.registerUser(username,password,phone);
            
            // Registration mehtod will show
            if (response.equals("User registered successfully.")) {
                System.out.println("\n" + response);
                isRegistered = true;
            } else {
                System.out.println("\nRegistration failed: " + response);
                System.out.println("Please try again.\n");
            }
        }
        
        // --- LOGIN SECTION ---
        System.out.println("\n=== USER LOGIN ===");

        boolean isLoggedIn = false;
        int attempts = 0;
        int maxAttempts = 5;

        while (!isLoggedIn && attempts < maxAttempts) {

            attempts++;
        
            System.out.print("Enter your username:");
            String loginUsername = input.nextLine();
            
            System.out.print("Enter your password:");
            String loginPassword = input.nextLine();
            
            // Call the LoginUser to check if the details match the ones stored
            boolean loggedIn = login.loginUser(loginUsername, loginPassword);
            
            //Print out the correct login message
            String loginMessage = login.returnLoginStatus(loggedIn);

            if (loggedIn) {
                System.out.println("\n" + loginMessage);
                isLoggedIn = true;
            } else {
                int remaining = maxAttempts - attempts;

                if (remaining > 0) {
                    System.out.println("\n" + loginMessage);
                    System.out.println("You have " + remaining + " attempt(s) remaining.\n");
                } else {
                    System.out.println("\nToo many failed attempts. Your account has been locked.");
                    System.out.println("Please contact support for assistance.");
                }
            }
        }

        input.close();
    }
    
}